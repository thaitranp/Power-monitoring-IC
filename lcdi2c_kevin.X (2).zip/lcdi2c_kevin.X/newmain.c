/*
 * File:   newmain.c
 * Author: Motin Howlader
 *
 * Created on March 20, 2017, 11:49 AM
 */


#include <xc.h>
#include <p24FJ256GA702.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libpic30.h>
#include <stddef.h>
#include <stdbool.h>


// FOSCSEL
#pragma config FNOSC = PRI        // Oscillator Source Selection->Primary Oscillator (XT, HS, EC)
#pragma config PLLMODE = DISABLED // PLL Mode Selection->No PLL used; PLLEN bit is not available
#pragma config IESO = ON          // Two-speed Oscillator Start-up Enable bit->Start up device with FRC, then switch to user-selected oscillator source

// FOSC
#pragma config POSCMD = HS        // Primary Oscillator Mode Select bits->HS Crystal Oscillator Mode
#pragma config OSCIOFCN = OFF     // OSC2 Pin Function bit->OSC2 is clock output
#pragma config SOSCSEL = OFF      // SOSC Power Selection Configuration bits->SOSC is used in crystal (SOSCI/SOSCO) mode
#pragma config PLLSS = PLL_PRI    // PLL Secondary Selection Configuration bit->PLL is fed by the Primary oscillator
#pragma config IOL1WAY = ON       // Peripheral pin select configuration bit->Allow only one reconfiguration
#pragma config FCKSM = CSDCMD     // Clock Switching Mode bits->Both Clock switching and Fail-safe Clock Monitor are disabled

// FWDT
#pragma config FWDTEN = OFF    // Watchdog Timer Enable bits->WDT and SWDTEN disabled

#pragma config JTAGEN = OFF

// Output pin definitions
#define LCD_RS LATBbits.LATB13 // LCD register select (0 for command, 1 for data)
#define LCD_E LATAbits.LATA4   // LCD operation enable (falling edge triggered)

#define _ISR_PSV __attribute__ ( ( interrupt,  auto_psv) )


//adding UART code
#define SYSCLK  32000000UL              // 8MHz clock
#define FCY  (SYSCLK/2)
// Output pin definitions
#define LCD_RS LATBbits.LATB13 // LCD register select (0 for command, 1 for data)
#define LCD_E LATAbits.LATA4   // LCD operation enable (falling edge triggered)
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable bit (Watchdog Timer in Non-Window mode)

#define STRLEN 12
char t;
int length;
char rcbuf[STRLEN];



static unsigned int t_tenths;
unsigned int data[40];
char s1[7], s2[7],s3[7], s4[7], s[20], status[20],uart[200];
long int freq;
char *pEnd;
double fr;
char checksum;
int byteIndex;
long int lm=1000000;
/*UART functions*/

void UART_init(void)
{
TRISBbits.TRISB15 = 0x001;
ANSBbits.ANSB15 = 0x000;
TRISBbits.TRISB14= 0x000;
ANSBbits.ANSB14 = 0x000;
__builtin_write_OSCCONL(OSCCON & 0xbf);
// Assign U1RX To Pin RP15
RPINR18bits.U1RXR = 0x0F;
//Assign U1TX to Pin RP14
RPOR7bits.RP14R = 0x03;
__builtin_write_OSCCONL(OSCCON | 0x40);
//data, parity and stop bit
U1MODEbits.BRGH = 0;
U1MODEbits.PDSEL = 00;
U1MODEbits.STSEL = 0;
//set baud rate
U1BRG = 103;
//interrupt config
U1STAbits.URXISEL = 00;
U1STAbits.UTXINV = 0;
//UART interrupt enable
IEC0bits.U1RXIE = 1; // interrupt on reception allowed
IEC0bits.U1TXIE = 0; // no interrupt on transmition
IEC4bits.U1ERIE = 1; // interrupts on errors allowed
IPC2bits.U1RXIP = 7; // interrupt level of reception
IPC16bits.U1ERIP = 6; // interrupt level on errors
//enable UART
U1MODEbits.UARTEN = 1;
U1STAbits.UTXEN = 1;
U1STAbits.URXEN = 1;

}

void UART_putc(char c)
{
     int k=0;
    while (!U1STAbits.TRMT)
    {
        k++;
        if(k>10000)
            break;
    }// wait until transmit shift register is empty
    U1TXREG = c;               // write character to TXREG and start transmission
    //__delay_ms(100);
    //Delay(10000);
}

void UART_puts(char *s)
{
    while (*s)
    {
        UART_putc(*s);     // send character pointed to by s
        s++;                // increase pointer location to the next character
    }
}

void _ISR_PSV _U1RXInterrupt(void)
{
   if(IFS0bits.U1RXIF)
{
    //lcd_command(0x01);
    int rcindex = 0;
    while(U1STAbits.URXDA)
    {
    t = U1RXREG;      // read received character to buffer
    rcbuf[rcindex] = t;
    rcindex ++;
    Delay(500);
    UART_puts("tx");
    }
    Delay(500);
    UART_puts(rcbuf);
    length = rcindex;
    rcindex = 0;
    U1STAbits.OERR = 0 ;
    IFS0bits.U1RXIF = 0;

}

 }

/*I2c function*/
//char data[10];
int Delay(unsigned long t){
    // Delay time is t*26/F_OSC = t*13/F_CY.
    // For 32 MHz oscillator, this is t*813 us.
    // i.e., t = 1230769 gives a delay of 1 s.
    unsigned long i;
    for(i = 0; i < t; i++){
    }
    return 0;
}

/**********************************************************/
// LCD driver
int lcd_command(char c){
    LATB = (LATB & 0xFF00) | c; // Put data on LCD port
    LCD_RS = 0; // Send command
    LCD_E = 1;
    Delay(40); // Enable pulse width: >= 1.25 us
    LCD_E = 0; // Clock on falling edge of LCD enable
    return;
}
int lcd_write_char(char c){
    LATB = (LATB & 0xFF00) | c; // Put data on LCD port
    LCD_RS = 1; // Send data
    LCD_E = 1;
    Delay(40); // Enable pulse width: >= 1.25 us
    LCD_E = 0; // Clock on falling edge of LCD enable
    return 0;
}
int lcd_write_str(char * s){
    char i = 0;
    while (s[i] != '\0'){
        lcd_write_char(s[i]);
        Delay(1);
        i++;
    }
    return 0;
}
int lcd_init(void){
    LCD_E = 0;
    Delay(20000); // Wait 625 us after power is applied
    lcd_command(0x38); // Function set: 8 bit interface, 2 lines, 5x8 font size
    Delay(2000); // Wait 62.5 us (hard-wired busy flag not avail)
    lcd_command(0x01); // Clear display
    Delay(2000); // Wait 62.5 us (hard-wired busy flag not avail)
    //lcd_command(0x02); // Return home
    lcd_command(0x0c); // Display ON, cursor OFF, blinking cursor OFF
    //command(0x06); // Entry mode set: move cursor right, don't shift display
    // R/W is wired low in hardware -- write only (cannot read data from LCD)
    return 0;
}
/**********************************************************/
void _ISR_PSV _T1Interrupt(){
    t_tenths++;
    IFS0bits.T1IF = 0;
}
/**********************************************************/
void _ISR_PSV _SI2C1Interrupt ( void )
{
    //lcd_write_char('s');
    IFS1bits.SI2C1IF = 0;
}

void INTERRUPT_Initialize (void)
{
    //    MICI: MI2C1 - I2C1 Master Events
    //    Priority: 1
        IPC4bits.MI2C1IP = 1;
    //    SICI: SI2C1 - I2C1 Slave Events
    //    Priority: 1
        IPC4bits.SI2C1IP = 1;
            /* MI2C1 - I2C1 Master Events */
    // clear the master interrupt flag
         IFS1bits.MI2C1IF = 0;
    // enable the master interrupt
    //     IEC1bits.MI2C1IE = 1;
}
void __attribute__( ( interrupt, no_auto_psv ) )_MI2C1Interrupt ( void )
{
     char sn[7];
    //lcd_command(0x01); // Clear display
    //Delay(100); // Wait 62.5 us (hard-wired busy flag not avail)
    //lcd_command(0x02); // Return home
    //lcd_write_str("");
    while(!I2C1STATbits.RBF);
    //lcd_write_str(" 9");
    //data = I2C1RCV<<8;
    //sprintf(sn, "%X", I2C1RCV);
    //lcd_write_str(sn);
    I2C1STATbits.RBF = 0;
}

int hextobin(char *hexadecimal)
{
    char *hexDigitToBinary[16] = {"0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111"};    
    char hexDigits[16] = {'0', '1', '2', '3', '4', '5', '6', '7', '8','9', 'A', 'B', 'C', 'D', 'E', 'F'};
    //char binaryNumber[100];
    memset(status, 0, sizeof status);
    int i = 0, j, index=0;  
   
    for(i=0; hexadecimal[i] != '\0'; i++)  {  
        for(j = 0; j < 16; j++){
            if(hexadecimal[i] == hexDigits[j]){
                strcat(status, hexDigitToBinary[j]);
            }
        }
    }  
   
   return 0;
}

int I2C_Initialize (void)
{
    ANSA = 0; // Digital (not analog) inputs
    TRISAbits.TRISA4 = 0;  // Set RA4 (LCD E) as output.
    TRISAbits.TRISA0 = 0;  // Set RA0 (XBee CTS) as output.

    ANSB = 0; // Digital (not analog) inputs
    TRISB = 0xFF00;        // Set Port B lower byte as output.
    TRISBbits.TRISB13 = 0; // Set RB13 (LCD RS) as output.
    
    // Reference clock output for MCP39F521 power monitor ICs
    REFOCONLbits.ROOUT = 1; // Output reference clock to pin
    REFOCONLbits.ROSEL = 1; // Clock source: Fcy
    REFOCONHbits.RODIV = 2; // Divide clock source (Fcy) by 4
    RPOR5bits.RP10R = 28; // Map reference clock to RB10
    //RPOR7bits.RP15R = 28; // Map reference clock to RB15 (**temp for debug)
    REFOCONLbits.ROEN = 1; // Enable reference clock output

    // I2C interrupts
    IPC4bits.MI2C1IP = 1; // Priority 1 for I2C1 Master Events
    IPC4bits.SI2C1IP = 1; // Priority 1 for I2C1 Slave Events
    IFS1bits.MI2C1IF = 0; // Clear the I2C1 master interrupt flag
    IFS1bits.SI2C1IF = 0; // Clear the I2C1 slave interrupt flag
    IEC1bits.MI2C1IE = 0;//1; // Enable the I2C1 master interrupt
    IEC1bits.SI2C1IE = 0;//1; // Enable the I2C1 slave interrupt
    I2C1CONHbits.BOEN = 0; 
    PMD1bits.I2C1MD = 0; // Keep I2C module enabled during idle and doze
    I2C1BRG = 0x4E; // 100 kHz baud rate (0x12 for 400 kHz)
    //I2C1BRG = 0x12; // 100 kHz baud rate (0x12 for 400 kHz)
    I2C1CONLbits.I2CSIDL = 0; // Continue operation in idle mode
    //I2C1CONLbits.ACKEN = 1; // Send acknowledge data bit in master receive mode
    I2C1CONLbits.ACKDT = 0; // In master receive mode, acknowledge data bit is ACK (rather than NACK)
    //FDEVOPT1bits.ALTI2C1 = 1; // Using RB8 and RB9 (default)
    I2C1CONLbits.STRICT = 0; //1; // Strict reserved addressing is enforced
    I2C1CONLbits.A10M = 0; // I2C1ADD is a 7-bit slave address
    I2C1ADD = 0x76; //Slave address of this device
    //I2C1ADD = 0x75; // Slave address of this device
    I2C1CONLbits.DISSLW = 1; // Disable slew rate control for standard mode
    I2C1CONHbits.SDAHT = 0; // 100 ns minimum hold time
    //I2C1CONHbits.SBCDE = 0; // Don't detect collision
    I2C1CONLbits.SMEN = 1; // Thresholds are compliant with the SMBus spec
    I2C1CONLbits.STREN = 0; //1; // Enable software or receive clock stretching, therefore clock must be release by slave when done on loading data to sync clock
    I2C1CONLbits.I2CEN = 1; // Enable the I2C module
   
    I2C1STATbits.IWCOL = 0;
    I2C1STATbits.I2COV=0; 
    I2C1CONLbits.RCEN = 0;  //Receive is idle
    //IFS1bits.MI2C1IF = 0;    //Clear the master interrupt flag
    //I2C1STATbits.IWCOL = 0;  //Reset any write collisions
    I2C1STATbits.BCL = 0;   //Reset any bus collisions
    I2C1STAT = 0x0000;
    return 0;
}
int i2cReciveData(int byte)
{
    unsigned int num;
    I2C1CONLbits.RCEN = 1; // Receive Enable
    num=0;
    while(I2C1CONLbits.RCEN)
    {
        num++;
        if(num>lm)break;
    }
    //while(I2C1CONLbits.RCEN);
    num=0;
    while(!I2C1STATbits.RBF)
    {
        num++;
        if(num>lm)break;
    }
    data[byte] = I2C1RCV;
    //sprintf (s, "%X", data);
    //lcd_write_str(s);
    I2C1STATbits.RBF = 0;
    I2C1CONLbits.ACKEN = 1;    
    num=0;
    while(I2C1CONLbits.ACKEN)
    {
        num++;
        if(num>lm)break;
    }
    return 0;
}
int main(void){
    //int data=0;
    //Delay(1000000);
    INTERRUPT_Initialize();
    UART_init();
    // Write to the LCD
    //Delay(100);
    //lcd_init();
    //lcd_write_str("Hello!");
    //lcd_command(0xc0); // Go to the beginning of 2nd line
    //lcd_write_str("123456789ABCDEFGHIJK");
    //Delay(400000); // Wait 62.5 us (hard-wired busy flag not avail)
    //lcd_command(0x01); // Clear display
    //Delay(2000); // Wait 62.5 us (hard-wired busy flag not avail)
    //lcd_command(0x02); // Return home
    //while(1);
   
   
    // 1. Assert a Start condition on SDAx and SCLx.

while(1)
{   
    long int num=0;
    char st[10];
    Delay(1000);
    I2C_Initialize();
    Delay(10000);
    while(I2C1STATbits.P)
   {
       num++;
       if(num>lm)break;
   }
    I2C1CONLbits.SEN = 1;
    num=0;
    while(I2C1CONLbits.SEN)
    {
        num++;
        if(num>lm)break;
    }
    //Delay(500);
    //lcd_write_char('x');
    //while(I2C1CONLbits.SEN);

    // 2. Send the I2C device address byte to the slave with a write indication.
    I2C1TRN = 0xEC; // Control byte/address (power monitor 1)
    //I2C1TRN = 0xEA;

    //I2C1TRN = 0xE8; // Control byte/address (power monitor 1)
    //I2C1TRN = 0xEA; // Control byte/address (power monitor 2)
    //data = I2C1STAT;
    //I2C1STATbits.IWCOL = 0;
    //while(I2C1STATbits.ACKSTAT);

    // 0x80 = 0000 0000 1000 0000
   
    // 3. Wait for and verify an Acknowledge from the slave.
    //while(I2C1STATbits.TRSTAT);
    //I2C1STATbits.I2COV = 0;
    num=0;
    while(I2C1STATbits.TBF)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.ACKSTAT)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    //while(I2C1STATbits.IWCOL);
    while(I2C1STATbits.TRSTAT)
    {
        num++;
        if(num>lm)break;
    }
    //}
    //Delay(1);
    I2C1TRN = 0xA5; // Header byte
    checksum = 0xA5;
    //sprintf(s, "%X", I2C1STAT);
    //lcd_write_str(s);
    num=0;
    while(I2C1STATbits.TBF)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.ACKSTAT)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.TRSTAT)
    {
        num++;
        if(num>lm)break;
    }
    // while(I2C1STATbits.IWCOL);
    I2C1TRN = 0x08; // Number of bytes in frame
    //sprintf(s, "%X", I2C1STAT);
    //lcd_write_str(s);
    checksum = checksum + 0x08;
    num=0;
    while(I2C1STATbits.TBF)
    {
        num++;
        if(num>lm)break;
    } 
    num=0;
    while(I2C1STATbits.ACKSTAT)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.TRSTAT)
    {
        num++;
        if(num>lm)break;
    }
    // while(I2C1STATbits.IWCOL);
    I2C1TRN = 0x41; // Command: Set address pointer
    checksum = checksum + 0x41;
    num=0;
    while(I2C1STATbits.TBF)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.ACKSTAT)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.TRSTAT)
    {
        num++;
        if(num>lm)break;
    }
    // while(I2C1STATbits.IWCOL);
    I2C1TRN = 0x00; // Address high
    checksum = checksum + 0x00;
    num=0;
    while(I2C1STATbits.TBF)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.ACKSTAT)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.TRSTAT)
    {
        num++;
        if(num>lm)break;
    }
    // while(I2C1STATbits.IWCOL);
    //I2C1TRN = 0x04; // Address low (Version)
    I2C1TRN = 0x02; // Address low (Frequency)
    checksum = checksum + 0x02;
    num=0;
    while(I2C1STATbits.TBF)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.ACKSTAT)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.TRSTAT)
    {
        num++;
        if(num>lm)break;
    }
    // while(I2C1STATbits.IWCOL);
    I2C1TRN = 0x4E; // Command: Register Read, N bytes
    checksum = checksum + 0x4E;
    num=0;
    while(I2C1STATbits.TBF)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.ACKSTAT)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.TRSTAT)
    {
        num++;
        if(num>lm)break;
    }
    // while(I2C1STATbits.IWCOL);
    I2C1TRN = 0x18; // Number of Bytes to Read (24)
    checksum = checksum + 0x18;
    num=0;
    while(I2C1STATbits.TBF)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.ACKSTAT)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.TRSTAT)
    {
        num++;
        if(num>lm)break;
    }
    // while(I2C1STATbits.IWCOL);
    I2C1TRN = checksum; // Checksum
    num=0;
    while(I2C1STATbits.TBF)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.ACKSTAT)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(I2C1STATbits.TRSTAT)
    {
        num++;
        if(num>lm)break;
    }
        // while(I2C1STATbits.IWCOL);
   
    // while(I2C1STATbits.IWCOL);
    num=0;
    I2C1CONLbits.PEN = 1;     // Initiate Stop condition
    while(I2C1CONLbits.PEN)
    {
        num++;
        if(num > lm) break;
    }
    //sprintf(s, "%X", ACKSTAT);
    //lcd_write_str(s);
     // lcd_write_str("sent");

    // 4. Send the first data byte (sometimes known as the command) to the slave.

    // 5. Wait for and verify an Acknowledge from the slave.

    // 6. Send the serial memory address low byte to the slave.

    // 7. Repeat Steps 4 and 5 until all data bytes are sent.

    Delay(1000);
        
    // 8. Assert a Repeated Start condition on SDAx and SCLx.
    //I2C1CONLbits.RSEN = 1; // Restart
    //while(I2C1CONLbits.RSEN); 
    num=0;
    I2C1CONLbits.SEN = 1; // Start
    while(I2C1CONLbits.SEN)
    {
        num++;
        if(num>lm)break;
    }
    //Delay(500);
    //IEC1bits.MI2C1IE = 1;
    // 9. Send the device address byte to the slave with a read indication.
    I2C1TRN = 0xED; // Control byte/address (Power monitor-1)
    //I2C1TRN = 0xEB; // Control byte/address   (Power monitor-2)
    // 10. Wait for and verify an Acknowledge from the slave.
    num=0;
    while(I2C1STATbits.TBF)
    {
        num++;
        if(num>lm)break;
    }
    //while(I2C1STATbits.TRSTAT);
    num=0;
    while(I2C1STATbits.ACKSTAT)
    {
        num++;
        if(num>lm)break;
    }
    
    // 10. Wait for and verify an Acknowledge from the slave.
    
    // 11. Enable master reception to receive serial memory data.
 //Delay(100);
    
    //I2C1STATbits.RBF = 0;
    I2C1CONLbits.RCEN = 1; // Receive Enable
    // 12. Generate an ACK or NACK condition at the end of a received byte of data.
    num=0;
    while(I2C1CONLbits.RCEN)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(!I2C1STATbits.RBF)
    {
        num++;
        if(num>lm)break;
    }
     //sprintf (s, "%X", I2C1STAT);
    //lcd_write_str(s);
    data[0] = I2C1RCV;
    //lcd_write_str(s);
    I2C1STATbits.RBF = 0;
    num=0;
    I2C1CONLbits.ACKEN = 1;
    while(I2C1CONLbits.ACKEN)
    {
        num++;
        if(num>lm)break;
    }
    
    I2C1CONLbits.RCEN = 1; // Receive Enable
    //while(I2C1CONLbits.RCEN);
     num=0;
    while(I2C1CONLbits.RCEN)
    {
        num++;
        if(num>lm)break;
    }
    num=0;
    while(!I2C1STATbits.RBF)
    {
        num++;
        if(num>lm)break;
    }
    data[1] = I2C1RCV;
    //sprintf (s, "%X", data);
    //lcd_write_str(s);
    I2C1STATbits.RBF = 0;
    I2C1CONLbits.ACKEN = 1;    
    num=0;
    while(I2C1CONLbits.ACKEN)
    {
        num++;
        if(num>lm)break;
    }
//Delay(100);
    Delay(500);
    I2C1CONLbits.RCEN = 1; // Receive Enable
     num=0;
    while(I2C1CONLbits.RCEN)
    {
        num++;
        if(num>lm)break;
    }
    //while(I2C1CONLbits.RCEN);
    num=0;
    while(!I2C1STATbits.RBF)
    {
        num++;
        if(num>lm)break;
    }
    data[2] = I2C1RCV;
    //sprintf (s, "%X", data);
    //lcd_write_str(s);
    I2C1STATbits.RBF = 0;
    I2C1CONLbits.ACKEN = 1;    
    num=0;
    while(I2C1CONLbits.ACKEN)
    {
        num++;
        if(num>lm)break;
    }
    Delay(500);
    //Delay(100);
    
    for(byteIndex=3;byteIndex<=28;byteIndex++)
    {
        int k=i2cReciveData(byteIndex);
    }
    
    num=0;
    I2C1CONLbits.PEN = 1;     // Initiate Stop condition
    while(I2C1CONLbits.PEN)
    {
        num++;
        if(num > lm) break;
    }
    //lcd_init();
    //sprintf (s, "%X", I2C1STAT);
    
    if((data[2]==6))
    {
        //Delay(1000);
        lcd_init();
        sprintf (s1, "%02x", data[8]);
        sprintf (s2, "%02x", data[9]);
        strcat(s2,s1);
        freq=strtol(s2,&pEnd,16);
        fr=(double) freq/10;
        sprintf (s, "%.02lf ", fr);
        sprintf (uart, "%.02lf ", fr);
        //strcat(st,s1);
        lcd_write_str(s);
                
        //Delay(2000);
        sprintf (s1, "%02x", data[10]);
        sprintf (s2, "%02x", data[11]);
        strcat(s2,s1);
        freq=strtol(s2,&pEnd,16);
        fr=(double) freq/1000;
        sprintf (s, "%.03lf ", fr);
        lcd_write_str(s);
        strcat(uart,s);
             
        lcd_command(0xc0); Delay(1); // Go to beginning of 2nd line
        
        sprintf(s1, "%02x", data[4]);
        hextobin(s1);
        //freq=strtol(s1,&pEnd,16);
        //utoa(s,freq,2);
        //lcd_write_str(status);
        
        sprintf (s1, "%02x", data[20]);
        sprintf (s2, "%02x", data[21]);
        sprintf (s3, "%02x", data[22]);
        sprintf (s4, "%02x", data[23]);
        strcat(s4,s3);
        strcat(s4,s2);
        strcat(s4,s1);
        freq=strtol(s4,&pEnd,16);
        fr=(double) freq/100;
        if(status[3]=='1')
        {
        sprintf (s, "%.02lf ", fr);
        }
        else
        {
        sprintf (s, "-%.02lf ", fr);
        }
        lcd_write_str(s);
        strcat(uart,s);
        sprintf (s1, "%02x", data[24]);
        sprintf (s2, "%02x", data[25]);
        sprintf (s3, "%02x", data[26]);
        sprintf (s4, "%02x", data[27]);
        strcat(s4,s3);
        strcat(s4,s2);
        strcat(s4,s1);
        freq=strtol(s4,&pEnd,16);
        fr=(double) freq/100;
        if(status[2]=='1')
        {
            sprintf (s, "%.02lf ", fr);
        }
        else
        {
            sprintf (s, "-%.02lf ", fr);
        };
        lcd_write_str(s);
        strcat(uart,s);
    
       
    }
  if(I2C1STATbits.BCL==1)
    {
        //I2C1CONLbits.I2CEN=0;
        
        //I2C1CONLbits.I2CEN=1;
        I2C1CONLbits.RSEN=1;
        while(!I2C1CONLbits.RSEN)
        {
            num++;
            if(num>lm)break;
        }
        I2C1STATbits.BCL=0;
    }
    if(I2C1STATbits.IWCOL==1)
    {
        I2C1STATbits.IWCOL=0;
        Delay(1000);
    }
    //lcd_write_str(s);
    
    
    UART_puts(uart);
    
    
        
    
    //lcd_write_str(uart);
    /*if(num<=10)
    {
    lcd_init();    
    sprintf(s, "%X", num);
    lcd_write_str(s);
    }*/
  //Delay(5000);
}    

while(1);
/*
    I2C1CONLbits.ACKEN = 1; // Send acknowledge sequences on master receive
    I2C1CONLbits.ACKDT = 0; // Send acknowledge sequences on master receive

    // Start interrupt to write the elapsed time to LCD.
    TMR1 = 0x00;          // Clear contents of the timer register
    t_tenths = 0;         // Elapsed time in tenths of seconds
    T1CONbits.TCKPS = 2;  // Prescaler 1:64
    PR1 = 24999;          // Load the period register (32e6/2/64/10 - 1 = 24999)
    IPC0bits.T1IP = 0x01; // Setup Timer1 interrupt for desired priority level
    IFS0bits.T1IF = 0;    // Clear the Timer1 interrupt status flag
    IEC0bits.T1IE = 1;    // Enable Timer1 interrupts
    T1CONbits.TON = 1;    // Start Timer1
    lcd_command(0x93);    // Move cursor
    Delay(1);
    lcd_write_char('s');  // seconds
    while(1){
       lcd_command(0x8c); // Set cursor position
       sprintf(s, 7, "%6.1f", t_tenths/10.);
        lcd_write_str(s);  // Write the elapsed time
    }*/
return 0;
}